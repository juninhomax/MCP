﻿import sys
from pathlib import Path
import os

# Ajouter le dossier courant au PYTHONPATH
sys.path.insert(0, str(Path(__file__).parent))

from slaves.windows.main import app
import uvicorn

if __name__ == "__main__":
    port = int(os.getenv("SLAVE_PORT", "8003"))
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")
